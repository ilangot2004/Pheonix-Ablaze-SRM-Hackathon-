from flask import Flask, render_template_string, request, redirect, url_for

app = Flask(__name__)

# HTML and CSS for the home page and phishing steps
HOME_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phishing Practice</title>
    <style>
        body {
            font-family: "Courier New", Courier, monospace;
            background-color: #000;
            color: #0f0;
            padding: 20px;
            margin: 0;
        }
        .container {
            text-align: center;
            margin-top: 50px;
        }
        button {
            background-color: #0f0;
            color: #000;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 18px;
        }
        button:hover {
            background-color: #0a0;
        }
        .terminal {
            border: 2px solid #0f0;
            background-color: #000;
            padding: 20px;
            width: 80%;
            margin: 0 auto;
            min-height: 300px;
            box-shadow: 0 0 10px #0f0;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Phishing Practice</h1>
    <button onclick="showAlert()">Try Phishing</button>
</div>

<script>
    function showAlert() {
        const confirmed = confirm("Connecting to secure connection. Do you wish to proceed?");
        if (confirmed) {
            window.location.href = "/phishing-types";
        }
    }
</script>
</body>
</html>
'''

# Linux-style phishing options page
PHISHING_TYPES_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phishing Types</title>
    <style>
        body {
            font-family: "Courier New", Courier, monospace;
            background-color: #000;
            color: #0f0;
            padding: 20px;
            margin: 0;
        }
        .terminal {
            border: 2px solid #0f0;
            background-color: #000;
            padding: 20px;
            width: 80%;
            margin: 0 auto;
            min-height: 300px;
            box-shadow: 0 0 10px #0f0;
        }
        .options {
            margin-top: 20px;
        }
        .options div {
            cursor: pointer;
            padding: 10px;
            border: 1px solid #0f0;
            margin: 5px 0;
        }
        button {
            background-color: #0f0;
            color: #000;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="terminal">
    <div class="output-line">Select the phishing type:</div>
    <div class="options">
        <div onclick="selectOption(1)">1) Spear phishing</div>
        <div onclick="selectOption(2)">2) Vishing</div>
        <div onclick="selectOption(3)">3) Email phishing</div>
        <div onclick="selectOption(4)">4) HTTPS phishing</div>
        <div onclick="selectOption(5)">5) Pharming</div>
        <div onclick="selectOption(6)">6) Pop-up phishing</div>
        <div onclick="selectOption(7)">7) Evil twin phishing</div>
        <div onclick="selectOption(8)">8) Watering hole phishing</div>
    </div>
    <button onclick="goBack()">Back</button>
</div>

<script>
    function selectOption(option) {
        window.location.href = "/invitation-types/" + option;
    }

    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>
'''

# Invitation types page
INVITATION_TYPES_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invitation Types</title>
    <style>
        body {
            font-family: "Courier New", Courier, monospace;
            background-color: #000;
            color: #0f0;
            padding: 20px;
            margin: 0;
        }
        .terminal {
            border: 2px solid #0f0;
            background-color: #000;
            padding: 20px;
            width: 80%;
            margin: 0 auto;
            min-height: 300px;
            box-shadow: 0 0 10px #0f0;
        }
        .options {
            margin-top: 20px;
        }
        .options div {
            cursor: pointer;
            padding: 10px;
            border: 1px solid #0f0;
            margin: 5px 0;
        }
        button {
            background-color: #0f0;
            color: #000;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="terminal">
    <div class="output-line">Select the type of invitation for the phishing attempt:</div>
    <div class="options">
        <div onclick="selectOption('festival')">1) Festival Invitation</div>
        <div onclick="selectOption('marriage')">2) Marriage Invitation</div>
        <div onclick="selectOption('diwali')">3) Diwali Deals</div>
        <div onclick="selectOption('birthday')">4) Birthday Invitation</div>
        <div onclick="selectOption('amazon')">5) Amazon Deals</div>
        <div onclick="selectOption('flipkart')">6) Flipkart Pages</div>
        <div onclick="selectOption('instagram')">7) Instagram Pages</div>
    </div>
    <button onclick="goBack()">Back</button>
</div>

<script>
    function selectOption(option) {
        window.location.href = "/redirect/" + option;
    }

    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>
'''

# Main route - Homepage
@app.route('/')
def home():
    return render_template_string(HOME_TEMPLATE)

# Route for phishing type selection
@app.route('/phishing-types')
def phishing_types():
    return render_template_string(PHISHING_TYPES_TEMPLATE)

# Route for invitation types based on phishing type selected
@app.route('/invitation-types/<phishing_type>')
def invitation_types(phishing_type):
    return render_template_string(INVITATION_TYPES_TEMPLATE)

# Route for final redirection after permissions request
@app.route('/redirect/<invitation>')
def redirect_to_site(invitation):
    # Mocking the camera and microphone permission request and then redirect to an actual site
    if invitation == "amazon":
        return redirect("https://www.amazon.com")
    elif invitation == "flipkart":
        return redirect("https://www.flipkart.com")
    elif invitation == "instagram":
        return redirect("https://www.instagram.com")
    # For simplicity, handle other invitations here with placeholders
    else:
        return f"<h1>Redirection to {invitation} page (this is a mock page)</h1>"

if __name__ == '__main__':
    app.run(debug=True)
